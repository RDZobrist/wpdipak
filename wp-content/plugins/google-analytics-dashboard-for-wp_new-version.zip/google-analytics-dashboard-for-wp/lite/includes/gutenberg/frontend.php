<?php

require_once EXACTMETRICS_PLUGIN_DIR . 'lite/includes/gutenberg/blocks/blocks.php';
