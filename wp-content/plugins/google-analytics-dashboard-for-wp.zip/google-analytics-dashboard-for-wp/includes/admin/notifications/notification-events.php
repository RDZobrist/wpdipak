<?php

$base = ExactMetrics();
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-visitors.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-audience.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-mobile-device.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-upgrade-to-pro.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-bounce-rate.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-returning-visitors.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-traffic-dropping.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-upgrade-for-search-console.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-upgrade-for-form-conversion.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-upgrade-for-email-summaries.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-upgrade-for-google-optimize.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-to-add-more-file-extensions.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-to-setup-affiliate-links.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-headline-analyzer.php';
