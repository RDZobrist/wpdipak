<?php
echo "{email}";
